// [Embed(source='/assets/icon/visualcharts/pie.png')]
// public static var pie:Class;

// [Embed(source='/assets/icon/visualcharts/bar.png')]
// public static var bar:Class;


// [Embed(source='/assets/icon/visualcharts/column.png')]
// public static var column:Class;


// [Embed(source='/assets/icon/visualcharts/area.png')]
// public static var area:Class;

// [Embed(source='/assets/icon/visualcharts/radar.png')]
// public static var radar:Class;

// [Embed(source='/assets/icon/visualcharts/pyramid.png')]
// public static var pyramid:Class;

// [Embed(source='/assets/icon/visualcharts/gauge.png')]
// public static var dial:Class;

// [Embed(source='/assets/icon/visualcharts/gauge.png')]
// public static var cirlgauge:Class;

// [Embed(source='/assets/icon/visualcharts/gauge.png')]
// public static var semclgauge:Class;


// [Embed(source='/assets/icon/visualcharts/gauge.png')]
// public static var clgauge:Class;

// [Embed(source='/assets/icon/visualcharts/LINE.png')]
// public static var line:Class;

// [Embed(source='/assets/icon/visualcharts/funnel.png')]
// public static var funnel:Class;

// [Embed(source='/assets/icon/general/copy.png')]
// public static var copyData:Class;

// [Embed(source='/assets/icon/visualcharts/treemap.png')]
// public static var treemap:Class;

// [Embed(source='/assets/icon/visualcharts/grid.png')]
// public static var nestedgrid:Class;

// [Embed(source='/assets/icon/visualcharts/textbox.png')]
// public static var text:Class;