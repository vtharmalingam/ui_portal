// To get Search Suggest Results
export const FETCH_SEARCH_SUGGEST = 'search_org/fetchSearchSuggest';

//To Get Global Search results
export const FETCH_GLOBAL_SEARCH_RESULT = 'search_org/fetchGlobalSrch';

// Get Insight Lookups
export const GET_INSIGHTLOOKUP_DATA = 'GET_INSIGHTLOOKUP_DATA';
//To init shortcuts for each datamart
export const INIT_DATAMART_SHORTCUTS = 'search_org/initDatamartShortcts';

//To init shortcuts for each datamart
export const FETCH_INSIGHT_LOOKUP = 'search_org/fetchInsightLookup';

export const UPDATE_LKUP_TITLE = 'search_org/updateSelectedLookupTitle';

//Update lookup query deatils..
export const UPDATE_LKUP_QUERY_DEATILS = 'search_org/updateLookupQueryDeatails';


//To Update Inisght lookup options expand or collapse
export const EXPAND_ALL_LKUP_OPTIONS = 'search_org/expandAllLkupOptions';

//To Update the filers for global search
export const UPDATE_GLOBAL_SEARCH_FILTERS = 'search_org/updateGlobSrchFilters';

//To Update the global search collapsable flags
export const UPDATE_GLOBAL_SEARCH_COLLAPSABLE_FLAGS = 'search_org/update_global_search_collapse_flags';


//To Update the global search collapsable flags
export const GET_REPORT_QUERY_BY_ID = 'datamartsrch/GET_REPORT_QUERY_BY_ID';


//To get perspective configs
export const GET_PERSPECTIVE_CONFIG_XML = 'search_org/getPerspectiveConfigXML';

//To get global search config...
export const GET_GLOBAL_SEARCH_CONFIG = 'search_org/geGlobalSearchConfig';

//To get global search config...
export const RESET_GLOBAL_SEARCH = 'search_org/resetGlobalSearch';



//To init shortcuts for each datamart
//export const INIT_DATAMART_SHORTCUTS = 'search_org/initDatamartShortcts';



//To init shortcuts for each datamart
//export const INIT_DATAMART_SHORTCUTS = 'search_org/initDatamartShortcts';